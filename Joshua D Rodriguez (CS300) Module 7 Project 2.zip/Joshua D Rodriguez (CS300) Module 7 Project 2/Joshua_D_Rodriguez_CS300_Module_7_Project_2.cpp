// Joshua David Rodriguez
// CS300 Project Two

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>

using namespace std;

// Structure to represent a course
struct Course {
    string courseId;
    string courseName;
    vector<string> prerequisites;
    Course* left;
    Course* right;

    // Constructor to intialize a course
    Course(string id, string name) {
        courseId = id;
        courseName = name;
        left = right = nullptr;
    }
};

// Binary Search Tree (BST) for course storage
class CourseBST {
private:
    // root node of the BST
    Course* root; 

    // In order traversal to display courses in alphabetical order
    void inOrder(Course* node) {
        if (node) {
            inOrder(node->left);
            cout << node->courseId << " - " << node->courseName << endl;
            inOrder(node->right);
        }
    }

    // Recursive function to insert a new course into the BST
    Course* insert(Course* node, string id, string name, vector<string> prereqs) {

        // If tree is empty or found insertion point
        if (!node) { 
            Course* newCourse = new Course(id, name);
            newCourse->prerequisites = prereqs;
            return newCourse;
        }

        // Insert course into the correct position based on course ID
        if (id < node->courseId) node->left = insert(node->left, id, name, prereqs);
        else node->right = insert(node->right, id, name, prereqs);
        return node;
    }

    // Recursive function to search for a course by it's ID
    Course* search(Course* node, string id) {
        if (!node || node->courseId == id) return node;
        if (id < node->courseId) return search(node->left, id);
        return search(node->right, id);
    }

public:
    // Constructor initializes an empty BST
    CourseBST() { root = nullptr; }

    // Inserts a course into the BST
    void insert(string id, string name, vector<string> prereqs) { root = insert(root, id, name, prereqs); }
    // Displays all courses in alphabetical order
    void displayCourses() { inOrder(root); }
    // Finds and returns a course based on course ID
    Course* findCourse(string id) { return search(root, id); }
};

// Function to load courses from CSV file
void loadCourses(CourseBST &bst, string filename) {
    ifstream file(filename);

    if (!file) { // Check if file opened successfully
        cout << "Error: Could not open file '" << filename << "'. Check the file name and path.\n";
        return;
    }

    string line;

    // Reads file line by line
    while (getline(file, line)) {
        stringstream ss(line);
        string id, name, prereq;
        vector<string> prereqs;
        
        // Reads course ID and name
        getline(ss, id, ',');
        getline(ss, name, ',');

        // Reads prerequisites if there are any
        while (getline(ss, prereq, ',')) {
            prereqs.push_back(prereq);
        }
        // Insert course into BST
        bst.insert(id, name, prereqs);
    }
    file.close(); // Closes the file
    cout << "Courses loaded successfully." << endl;
}

// Function to print course details
void printCourse(CourseBST &bst) {
    string courseId;
    cout << "Enter course ID: ";
    cin >> courseId;

    // Searches for course in BST
    Course* course = bst.findCourse(courseId); 
    if (course) {
        // Displays course details
        cout << "\nCourse ID: " << course->courseId << "\nCourse Name: " << course->courseName << "\nPrerequisites: ";
        // If no prerequisites, displays "None"
        if (course->prerequisites.empty()) cout << "None";
        else for (string prereq : course->prerequisites) cout << prereq << " ";
        cout << "\n";
    } else {
        // Displays error if course not found
        cout << "Course not found.\n"; 
    }
}

// Function to clear the terminal screen
void clearScreen() {
#ifdef _WIN32
    system("CLS"); // For Windows
#else
    system("clear"); // For Linux/MacOS
#endif    
}

// Main menu
void displayMenu() {
    CourseBST bst; // Initialize BST to store course data
    int choice;
    string filename;
    bool isLoaded = false; //Checks to see if CSV file is loaded

    do {
        // Display menu options
        cout << "\nMenu:" << endl;
        cout << "1. Load Courses" << endl;
        cout << "2. Display All Courses" << endl;
        cout << "3. Find Course" << endl;
        cout << "9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        clearScreen(); // Clears the terminal screen

        switch (choice) {
            // Loads course data from CSV file
            case 1:
                cout << "PLEASE ENTER A FULL FILE NAME AND PLACE FILE IN THE ROOT FOLDER OF THIS PROGRAM \n Thank You!! :) \n\n Enter the CSV file name: ";
                cin.ignore(); // clears newline character from previous input
                getline(cin, filename); // Reads full file name, including spaces
                loadCourses(bst, filename);
                isLoaded = true;
                break;
            
            // Displays all courses from CSV file
            case 2: 
                if (!isLoaded) { // if the CSV file is not loaded
                    cout << "Error: Please load a CSV file first.\n";
                } else { // if the CSV file is loaded, display the courses
                    bst.displayCourses();
                }
                break;
            
            // Displays specific course from CSV file
            case 3:
                if (!isLoaded) { // if the CSV file is not loaded
                    cout << "Error: Please load a CSV file first.\n";
                } else { // if the CSV file is loaded, print the course
                    printCourse(bst);
                }
                break;
            
            // Exits the program
            case 9: 
                cout << "Exiting program." << endl;
                break;
            
            // Input validation
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 9); // Loops menu until user exits
}

// Starts program by displaying the menu
int main() {
    displayMenu();
    return 0;
}
